// FreshBooks Speed Boost - Content Script
(function() {
  'use strict';

  const CONFIG = {
    pageSize: 50,
    checkInterval: 500,
    maxChecks: 100
  };

  let merchantCache = [];
  let currentPage = 0;
  let allMerchants = [];
  let isInitialized = false;
  let checkCount = 0;
  let isOptimizing = false;
  let lastOptimizedDropdown = null;

  /**
   * Initialize pagination for merchant dropdown
   */
  function initializePagination() {
    if (isInitialized) return;

    const merchantInput = document.querySelector(
      '[data-ebd-id="ember361582-trigger"], .ember-power-select-typeahead-input'
    );

    if (!merchantInput) {
      checkCount++;
      if (checkCount < CONFIG.maxChecks) {
        setTimeout(initializePagination, CONFIG.checkInterval);
      }
      return;
    }

    console.log('[FreshBooks Speed Boost] Initializing merchant dropdown optimization...');

    // Intercept dropdown opening
    merchantInput.addEventListener('click', handleInputClick);
    merchantInput.addEventListener('focus', handleInputFocus);
    merchantInput.addEventListener('input', handleInputChange);

    isInitialized = true;
    console.log('[FreshBooks Speed Boost] Merchant dropdown initialized');
  }

  /**
   * Handle input click to optimize dropdown
   */
  function handleInputClick(e) {
    setTimeout(() => optimizeDropdown(), 100);
  }

  /**
   * Handle input focus to optimize dropdown
   */
  function handleInputFocus(e) {
    setTimeout(() => optimizeDropdown(), 100);
  }

  /**
   * Handle input change to reset pagination
   */
  function handleInputChange(e) {
    currentPage = 0;
    lastOptimizedDropdown = null; // Allow re-optimization after filtering
    setTimeout(() => optimizeDropdown(), 100);
  }

  /**
   * Check if user is actively filtering/searching
   */
  function isUserFiltering() {
    const merchantInput = document.querySelector(
      '[data-ebd-id="ember361582-trigger"], .ember-power-select-typeahead-input'
    );

    if (!merchantInput) return false;

    // If there's text in the input, user is filtering
    const inputValue = merchantInput.value || '';
    return inputValue.trim().length > 0;
  }

  /**
   * Main optimization function for the dropdown
   */
  function optimizeDropdown() {
    // Prevent infinite loops
    if (isOptimizing) return;

    const dropdown = document.querySelector(
      '[role="listbox"], .ember-power-select-dropdown'
    );

    if (!dropdown || !dropdown.offsetParent) return; // Hidden or doesn't exist

    const items = dropdown.querySelectorAll('[role="option"]');

    if (items.length === 0) return;

    // If user is filtering, don't paginate - show all filtered results
    if (isUserFiltering()) {
      console.log('[FreshBooks Speed Boost] User is filtering, skipping pagination');
      // Remove pagination controls if they exist
      const existingPagination = document.querySelector('.merchant-pagination-controls');
      if (existingPagination) {
        existingPagination.remove();
      }
      // Show all items
      items.forEach(item => {
        item.style.display = '';
        item.style.visibility = 'visible';
      });
      return;
    }

    // Check if this dropdown is already optimized
    if (dropdown === lastOptimizedDropdown && dropdown.querySelector('.merchant-pagination-controls')) {
      return;
    }

    isOptimizing = true;

    try {
      // Cache all merchants
      allMerchants = Array.from(items);
      console.log(`[FreshBooks Speed Boost] Found ${allMerchants.length} merchants`);

      // Hide excess items
      limitDisplayedItems();

      // Add pagination UI if needed
      if (allMerchants.length > CONFIG.pageSize) {
        addPaginationUI(dropdown);
      }

      lastOptimizedDropdown = dropdown;
    } finally {
      isOptimizing = false;
    }
  }

  /**
   * Limit displayed items to current page
   */
  function limitDisplayedItems() {
    const startIdx = currentPage * CONFIG.pageSize;
    const endIdx = startIdx + CONFIG.pageSize;

    allMerchants.forEach((item, idx) => {
      if (idx >= startIdx && idx < endIdx) {
        item.style.display = '';
        item.style.visibility = 'visible';
      } else {
        item.style.display = 'none';
        item.style.visibility = 'hidden';
      }
    });

    // Remove existing pagination UI
    const existingPagination = document.querySelector('.merchant-pagination-controls');
    if (existingPagination) {
      existingPagination.remove();
    }

    if (allMerchants.length > CONFIG.pageSize) {
      addPaginationUI(document.querySelector('[role="listbox"]'));
    }
  }

  /**
   * Add pagination controls to dropdown
   */
  function addPaginationUI(dropdownElement) {
    // Don't add if already exists
    if (document.querySelector('.merchant-pagination-controls')) return;

    const totalPages = Math.ceil(allMerchants.length / CONFIG.pageSize);
    const container = document.createElement('div');
    container.className = 'merchant-pagination-controls';
    container.style.cssText = `
      padding: 10px;
      border-top: 1px solid #ddd;
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 12px;
      background: #f9f9f9;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    `;

    // Info text
    const infoSpan = document.createElement('span');
    infoSpan.textContent = `Page ${currentPage + 1} of ${totalPages} (${allMerchants.length} total)`;
    infoSpan.style.cssText = 'color: #666; flex: 1;';

    // Prev button
    const prevBtn = document.createElement('button');
    prevBtn.textContent = '← Previous';
    prevBtn.disabled = currentPage === 0;
    prevBtn.style.cssText = `
      padding: 6px 12px;
      margin-right: 5px;
      background: #0075dd;
      color: white;
      border: none;
      border-radius: 3px;
      cursor: pointer;
      font-size: 12px;
      ${currentPage === 0 ? 'opacity: 0.5; cursor: not-allowed;' : ''}
    `;
    prevBtn.addEventListener('click', () => {
      if (currentPage > 0) {
        currentPage--;
        limitDisplayedItems();
      }
    });

    // Next button
    const nextBtn = document.createElement('button');
    nextBtn.textContent = 'Next →';
    nextBtn.disabled = currentPage === totalPages - 1;
    nextBtn.style.cssText = `
      padding: 6px 12px;
      margin-left: 5px;
      background: #0075dd;
      color: white;
      border: none;
      border-radius: 3px;
      cursor: pointer;
      font-size: 12px;
      ${currentPage === totalPages - 1 ? 'opacity: 0.5; cursor: not-allowed;' : ''}
    `;
    nextBtn.addEventListener('click', () => {
      if (currentPage < totalPages - 1) {
        currentPage++;
        limitDisplayedItems();
      }
    });

    container.appendChild(prevBtn);
    container.appendChild(infoSpan);
    container.appendChild(nextBtn);

    // Append to dropdown
    if (dropdownElement) {
      dropdownElement.appendChild(container);
    }
  }

  /**
   * Watch for dropdown changes and optimize when visible
   */
  function setupMutationObserver() {
    let debounceTimer = null;

    const observer = new MutationObserver((mutations) => {
      // Debounce to avoid excessive calls
      if (debounceTimer) clearTimeout(debounceTimer);

      debounceTimer = setTimeout(() => {
        // Check if dropdown was added to DOM
        const dropdown = document.querySelector('[role="listbox"]');
        if (dropdown && dropdown.offsetParent !== null && !isOptimizing) {
          optimizeDropdown();
        } else if (!dropdown || !dropdown.offsetParent) {
          // Dropdown closed, reset optimization flag
          lastOptimizedDropdown = null;
        }
      }, 50);
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true,
      attributes: false,
      characterData: false
    });
  }

  // Start initialization when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializePagination);
  } else {
    initializePagination();
  }

  // Also set up mutation observer to catch dropdown creation
  setupMutationObserver();

  console.log('[FreshBooks Speed Boost] Content script loaded');
})();
